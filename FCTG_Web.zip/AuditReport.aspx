﻿<%@ Page Title="" Language="C#" MasterPageFile="~/masterPage.Master" AutoEventWireup="true" CodeBehind="AuditReport.aspx.cs" Inherits="FCTG_WEB.pnrAuditReport" %>

<asp:Content ID="Content2" ContentPlaceHolderID="mainBodyContent" runat="server">
    <asp:ScriptManager runat="server"></asp:ScriptManager>
    <asp:UpdatePanel ID="updPanel" runat="server">
        <ContentTemplate>
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <div class="content-header d-none">
                    <div class="container-fluid">
                        <div class="row mb-2">
                            <div class="col-sm-6">
                                <h1 class="m-0 pageTitle">Query Audit Report</h1>
                            </div>
                            <!-- /.col -->
                           <%-- <div class="col-sm-6">
                                <ol class="breadcrumb float-sm-right">
                                    <li class="breadcrumb-item active">Report</li>
                                    <li class="breadcrumb-item active">Query Audit Report</li>
                                </ol>
                            </div>--%>
                            <!-- /.col -->
                        </div>
                        <!-- /.row -->
                    </div>
                    <!-- /.container-fluid -->
                </div>
                <!-- /.content-header -->

                <!-- Main content -->
                <section class="content">
                    <div class="container-fluid">
                        <!-- Small boxes (Stat box) -->
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h3 class="card-title font-weight-bold">
                                            <i class="fas fa-chart-pie mr-1"></i>
                                            Query Audit Report</h3>
                                    </div>
                                    <!-- /.card-header -->
                                    <div class="card-body">
                                        <div class="form-row">
                                            <div class="input-group datepicker form-group col-sm-6 col-md-2 col-lg-2" id="reservationdate1" data-target-input="nearest">
                                                <asp:TextBox type="text" ID="txtFromDate" name="txtFromDate" runat="server" CssClass="form-control datetimepicker-input" placeholder="Inflow From Date" data-date-format="yyyy/MM/dd" data-target="#reservationdate1"></asp:TextBox>
                                                <div class="input-group-append" id="lblFromDate" runat="server" data-target="#reservationdate1" data-toggle="datetimepicker">
                                                    <span class="input-group-text"><i class="fa fa-calendar-alt text-danger" id="icontxtFromDate"></i></span>
                                                </div>
                                            </div>
                                            <div class="input-group datepicker form-group col-sm-6 col-md-2 col-lg-2" id="reservationdate2" data-target-input="nearest">
                                                <asp:TextBox type="text" ID="txtToDate" name="txtToDate" runat="server" CssClass="form-control datetimepicker-input" placeholder="Inflow To Date" data-date-format="yyyy/MM/dd" data-target="#reservationdate2"></asp:TextBox>
                                                <div class="input-group-append" id="lblToDate" runat="server" data-target="#reservationdate2" data-toggle="datetimepicker">
                                                    <span class="input-group-text"><i class="fa fa-calendar-alt text-danger" id="icontxtToDate"></i></span>
                                                </div>
                                            </div>
                                            <div class="input-group datepicker form-group col-sm-6 col-md-2 col-lg-2" id="reservationdate3" data-target-input="nearest">
                                                <asp:TextBox type="text" ID="txtActionFromDate" name="txtActionFromDate" runat="server" CssClass="form-control datetimepicker-input" placeholder="Action From Date" data-date-format="yyyy/MM/dd" data-target="#reservationdate3"></asp:TextBox>
                                                <div class="input-group-append" id="lblActionFromDate" runat="server" data-target="#reservationdate3" data-toggle="datetimepicker">
                                                    <span class="input-group-text"><i class="fa fa-calendar-alt text-danger"></i></span>
                                                </div>
                                            </div>
                                            <div class="input-group datepicker form-group col-sm-6 col-md-2 col-lg-2" id="reservationdate4" data-target-input="nearest">
                                                <asp:TextBox type="text" ID="txtActionToDate" name="txtActionToDate" runat="server" CssClass="form-control datetimepicker-input" placeholder="Action To Date" data-date-format="yyyy/MM/dd" data-target="#reservationdate4"></asp:TextBox>
                                                <div class="input-group-append" id="lblActionToDate" runat="server" data-target="#reservationdate4" data-toggle="datetimepicker">
                                                    <span class="input-group-text"><i class="fa fa-calendar-alt text-danger" id="icontxtActionToDate"></i></span>
                                                </div>
                                            </div>
                                            <div class="form-group col-sm-6 col-md-2 col-lg-2" runat="server" id="reservationdate5">
                                                <asp:TextBox type="text" ID="txtPNR" name="txtPNR" runat="server" CssClass="form-control" placeholder="Query ID"></asp:TextBox>
                                            </div>
                                            <div class="form-group col-sm-6 col-md-2 col-lg-2">
                                                <asp:Button ID="btnRefresh" runat="server" CssClass="btn btn-primary" Text="Refresh List" OnClick="btnRefreshList_Click" OnClientClick="return Validation();" type="button" />
                                                <asp:Button ID="btnExport" runat="server" CssClass="btn btn-primary" Text="Export" OnClick="btnExport_Click"  OnCLientClick="return startExport();"/>
                                            </div>
                                        </div>
                                        
                                        <div class="tab-content p-0">
                                            <asp:Repeater runat="server" ID="rptPNRAudit">
                                                <HeaderTemplate>
                                                    <div class="table-responsive">
                                                        <table class="table border table-striped table-bordered table-hover mb-0 gridViewTable text-nowrap" id="applicationAuditTable" style="width: 100%">
                                                            <thead>
                                                                <tr>
                                                                    <th>#</th>
                                                                    <th>Year</th>
                                                                    <th>Month</th>
                                                                    <th>Case Type</th>
                                                                    <th>Case Number</th>
                                                                    <th>Worklist</th>
                                                                    <%--<th>Account Code</th>
<th>Case Type</th>--%>
                                                                    <th>Inflow At</th>
                                                                    <th>Assigned To</th>
                                                                    <th>Assigned At</th>
                                                                    <th>Action Taken</th>
                                                                    <th>Actioned By</th>
                                                                    <th>Actioned At</th>
                                                                    <th>Remark</th>
                                                                    <th>Global Customer</th>
                                                                    <th>Global Customer Name</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                </HeaderTemplate>
                                                <ItemTemplate>
                                                    <tr>
                                                        <td><%# Container.ItemIndex + 1 %></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.YEAR")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.MONTH")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.Case_Type")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.RECORD_LOCATOR")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.FUNCTION")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.EXTRACTION_DATE")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.ALLOCATED_TO_USERNAME")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.ALLOCATION_DATE")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.ACTION_TAKEN")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.ACTION_TAKEN_BY_USERNAME")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.ACTION_DATE")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.COMMENTS")%></td>
                                                           <td class="more"><%# DataBinder.Eval(Container, "DataItem.GLOBAL_CUSTOMER")%></td>
                                                           <td class="more"><%# DataBinder.Eval(Container, "DataItem.GLOBAL_CUSTOMER_NAME")%></td>
                                                    </tr>
                                                </ItemTemplate>
                                                <FooterTemplate>
                                                    </tbody>
                                                    </table>
                                                    </div>
                                                </FooterTemplate>
                                            </asp:Repeater>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.card-body -->
                            </div>
                        </div>
                        <!-- /.col-->
                    </div>
                    <!-- /.row -->
                    <!-- /.container-fluid -->
                </section>
                <!-- /.content -->
            </div>
            <script type="text/javascript">

                $(window).on('load', function () {
                    $('#preloader').fadeOut('slow');
                });

                $(document).ready(function () {
                    if (typeof (Sys) != "undefined") {
                        var prm = Sys.WebForms.PageRequestManager.getInstance();
                        prm.add_endRequest(function () {
                            $('#reservationdate1, #reservationdate2,#reservationdate3,#reservationdate4').datetimepicker({
                                format: 'L'
                            });
                        })
                    };
                    //Date picker
                    $('#reservationdate1, #reservationdate2,#reservationdate3,#reservationdate4').datetimepicker({
                        format: 'L'
                    });
                });


                function Validation() {
                    $('.error').remove();
                    var flag = true;
                    var ifd = $('#<%=txtFromDate.ClientID%>').val();
                    var itd = $('#<%=txtToDate.ClientID%>').val();
                    var cfd = $('#<%=txtActionFromDate.ClientID%>').val();
                    var ctd = $('#<%=txtActionToDate.ClientID%>').val();
                    var PNR = $('#<%=txtPNR.ClientID%>').val();

                    if (ifd == "" && itd == "" && cfd == "" && ctd == "" && PNR == "") {
                        //alert("Please select inflow or completion date range or Query ID to proceed!");
                        $('#<%=txtFromDate.ClientID%>').addClass('border border-danger');
                        $('#<%=lblFromDate.ClientID%>').after('<div class="text-danger mt-2 d-block error">Please enter Inflow From Date</div>');
                        $('#<%=txtToDate.ClientID%>').addClass('border border-danger');
                        $('#<%=lblToDate.ClientID%>').after('<div class="text-danger mt-2 d-block error">Please enter Inflow To Date</div>');

                        $('#<%=txtActionFromDate.ClientID%>').addClass('border border-danger');
                        $('#<%=lblActionFromDate.ClientID%>').after('<div class="text-danger mt-2 d-block error">Please enter Action From Date</div>');
                        $('#<%=txtActionToDate.ClientID%>').addClass('border border-danger');
                        $('#<%=lblActionToDate.ClientID%>').after('<div class="text-danger mt-2 d-block error">Please enter Action To Date</div>');

                        $('#<%=txtPNR.ClientID%>').addClass('border border-danger');
                        $('#<%=txtPNR.ClientID%>').after('<div class="text-danger mt-2 d-block error">Please enter Query Id</div>');
                        flag = false;
                    }

                    if (ifd != '') {
                        if (Date.parse(ifd) > Date.parse(itd)) {
                            $('.error').remove();
                            $('input').removeClass('border border-success border-danger');
                            $('#<%=txtToDate.ClientID%>').addClass('border-danger');
                            $('#<%=lblToDate.ClientID%>').siblings().remove('#err');
                            $('#<%=lblToDate.ClientID%>').after('<div id="err" class="text-danger mt-2 d-block error">To Date should be greater than From date</div>');
                            $('#<%=txtFromDate.ClientID%>').removeClass('border-danger').addClass('border-success');
                            flag = false;
                        } else {
                            $('#<%=txtToDate.ClientID%>').removeClass('border-danger');
                            $('#<%=lblToDate.ClientID%>').remove('#err');
                        }
                    }
                    if (cfd != '') {
                        if (Date.parse(cfd) > Date.parse(ctd)) {
                            $('.error').remove();
                            $('input').removeClass('border border-success border-danger');
                            $('#<%=txtActionToDate.ClientID%>').addClass('border-danger');
                            $('#<%=lblActionToDate.ClientID%>').siblings().remove('#err');
                            $('#<%=lblActionToDate.ClientID%>').after('<div id="err" class="text-danger mt-2 d-block error">Completion To Date should be greater than Completion From date</div>');
                            $('#<%=txtActionFromDate.ClientID%>').removeClass('border-danger').addClass('border-success');
                            flag = false;
                        } else {
                            $('#<%=txtActionToDate.ClientID%>').removeClass('border-danger');
                            $('#<%=lblActionToDate.ClientID%>').remove('#err');
                        }
                    }

                    if (ifd != "" && itd == "") {
                        $('.error').remove();
                        $('input').removeClass('border border-success border-danger');
                        //alert("Please select inflow date range to proceed!");
                        $('#<%=txtFromDate.ClientID%>').removeClass('border-danger').addClass('border-success');
                        $('#<%=txtToDate.ClientID%>').addClass('border border-danger');
                        $('#<%=lblToDate.ClientID%>').after('<div class="text-danger mt-2 d-block error">Please enter Inflow To Date</div>');
                        $('#<%=txtActionFromDate.ClientID%>,#<%=txtActionToDate.ClientID%>').removeClass('border border-danger');
                        flag = false;
                    }
                    if (ifd == "" && itd != "") {
                        $('.error').remove();
                        $('input').removeClass('border border-success border-danger');
                        //alert("Please select inflow date range to proceed!");
                        $('#<%=txtToDate.ClientID%>').removeClass('border-danger').addClass('border-success');
                        $('#<%=txtFromDate.ClientID%>').addClass('border border-danger');
                        $('#<%=lblFromDate.ClientID%>').after('<div class="text-danger mt-2 d-block error">Please enter Inflow From Date</div>');
                        $('#<%=txtActionFromDate.ClientID%>,#<%=txtActionToDate.ClientID%>').removeClass('border border-danger');
                        flag = false;
                    }
                    if (cfd != "" && ctd == "") {
                        $('.error').remove();
                        $('input').removeClass('border border-success border-danger');
                        //alert("Please select action date range to proceed!");
                        $('#<%=txtActionFromDate.ClientID%>').removeClass('border-danger').addClass('border-success');
                        $('#<%=txtActionToDate.ClientID%>').addClass('border border-danger');
                        $('#<%=lblActionToDate.ClientID%>').after('<div class="text-danger mt-2 d-block error">Please enter Action To Date</div>');
                        flag = false;
                    }
                    if (cfd == "" && ctd != "") {
                        $('.error').remove();
                        $('input').removeClass('border border-success border-danger');
                        //alert("Please select action date range to proceed!");
                        $('#<%=txtActionToDate.ClientID%>').removeClass('border-danger').addClass('border-success');
                        $('#<%=txtActionFromDate.ClientID%>').addClass('border border-danger');
                        $('#<%=lblActionFromDate.ClientID%>').after('<div class="text-danger mt-2 d-block error">Please enter Action From Date</div>');
                        flag = false;
                    }
                    //if (PNR !== "") {
                    //    $('.error').remove();
                    //    $('input').removeClass('border border-success border-danger');
                    //    flag = false;
                    //}
                    //if ((ifd == "" && itd == "" && cfd == "" && ctd == "" && (PNR == "" || PNR == ""))) {
                    //    //msg = "Please select Fi!";
                    //    //log(msg);
                    //    flag = false;
                    //}

                    return flag;
                }

                var exportTimer = null;
                var attemptCounter = 0;
                function startExport() {
                    // Show the overlay and loader
                    var loader = document.getElementById('exportLoader');

                    if (loader) {
                        loader.style.setProperty('display', 'flex', 'important');
                    }
                    attemptCounter = 0;
                    if (exportTimer) {
                        clearInterval(exportTimer);
                        exportTimer = null;
                    }

                    exportTimer = setInterval(function () {
                        attemptCounter++;

                        if (attemptCounter >= 30) {
                            clearInterval(exportTimer);
                            exportTimer = null;

                            var targetLoader = document.getElementById('exportLoader');
                            if (targetLoader) {
                                targetLoader.style.setProperty('display', 'none', 'important');
                            }
                            return;
                        }

                        var cookies = document.cookie.split(';');

                        for (var i = 0; i < cookies.length; i++) {
                            var cookie = cookies[i].trim();
                            if (cookie.indexOf("ExportDownloadToken=") !== -1 || cookie.indexOf("ExportDownloadComplete=") !== -1) {
                               
                                clearInterval(exportTimer);

                                // Hide the overlay when download finishes

                                var targetLoader = document.getElementById('exportLoader');
                                if (targetLoader) {
                                    targetLoader.style.setProperty('display', 'none', 'important');
                                }

                                // Remove the completion cookie
                                document.cookie = "ExportDownloadToken=; Max-Age=0; path=/; SameSite=Lax";
                                document.cookie = "ExportDownloadComplete=; Max-Age=0; path=/; SameSite=Lax";
                                break;
                            }
                        }

                    }, 500);

                    setTimeout(function () {

                        var targetLoader = document.getElementById('exportLoader');
                        if (targetLoader) {
                            targetLoader.style.setProperty('display', 'none', 'important');
                        }
                    }
                        , 4000);

                    return true;
                }

            </script>
        </ContentTemplate>
      <Triggers>
<asp:PostBackTrigger ControlID="btnExport" />
</Triggers>
   </asp:UpdatePanel>

    <div id="exportLoader" style="display:none;position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.3);z-index:9999;justify-content:center;align-items:center;">

        <div  style="background:rgba(255,255,255,0.8);padding:10px;border-radius:5px;transform:translate(-50%,-50%); z-index:999;text-align:center;">"         
            
        <img src="malkom-static-assets/common/images/Loader.gif"
                alt="Loading..." />
        <br />
        <span>Please wait...</span>
    </div>
    </div>

    <asp:UpdateProgress ID="UpdateProgress1" runat="server" AssociatedUpdatePanelID="updPanel">
    <ProgressTemplate>
        <div id="overlayBlocker"
            style="position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background-color: rgba(0,0,0,0.3); z-index: 998;">
        </div>
        <div style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 999; background: rgba(255, 255, 255, 0.8); padding: 10px; border-radius: 5px; text-align: center;">
            <img src="malkom-static-assets/common/images/Loader.gif" alt="Loading..." />
            <br />
            <span>Please wait...</span>
        </div>
    </ProgressTemplate>
</asp:UpdateProgress>
    <!-- /.content-wrapper -->
</asp:Content>
