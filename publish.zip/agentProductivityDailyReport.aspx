﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="agentProductivityDailyReport.aspx.cs" MasterPageFile="~/masterPage.Master" Inherits="FCTG_Web.agentProductivityDailyReport" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="mainBodyContent" runat="server">
    <asp:ScriptManager runat="server"></asp:ScriptManager>
    <asp:UpdatePanel ID="updPanel" runat="server">
        <ContentTemplate>
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <div class="content-header d-none">
                    <div class="container-fluid">
                        <div class="row mb-2">
                            <div class="col-sm-6">
                                <h1 class="m-0 pageTitle">Agent Productivity Daily Report</h1>
                            </div>
                            <!-- /.col -->
                           <%-- <div class="col-sm-6">
                                <ol class="breadcrumb float-sm-right">
                                    <li class="breadcrumb-item active">Report</li>
                                    <li class="breadcrumb-item active">Agent Productivity Daily Report</li>
                                </ol>
                            </div>--%>
                            <!-- /.col -->
                        </div>
                        <!-- /.row -->
                    </div>
                    <!-- /.container-fluid -->
                </div>
                <!-- /.content-header -->

                <!-- Main content -->
                <section class="content">
                    <div class="container-fluid">
                        <!-- Small boxes (Stat box) -->
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h3 class="card-title font-weight-bold">
                                            <i class="fas fa-chart-pie mr-1"></i>
                                            Agent Productivity Daily Report</h3>
                                    </div>
                                    <!-- /.card-header -->
                                    <div class="card-body">
                                        <div class="form-row">
                                            <div class="input-group datepicker form-group col-sm-6 col-md-2 col-lg-2" id="reservationdate" data-target-input="nearest">
                                                <asp:TextBox type="text" ID="txtFromDate" name="txtFromDate" runat="server" CssClass="form-control datetimepicker-input" placeholder="From Date" data-date-format="yyyy/MM/dd" data-target="#reservationdate"></asp:TextBox>
                                                <div class="input-group-append" id="lblFromDate" runat="server" data-target="#reservationdate" data-toggle="datetimepicker">
                                                    <span class="input-group-text"><i class="fa fa-calendar-alt text-danger" id="icontxtFromDate"></i></span>
                                                </div>
                                            </div>
                                            <div class="input-group datepicker form-group col-sm-6 col-md-2 col-lg-2" id="reservationdate2" data-target-input="nearest">
                                                <asp:TextBox type="text" ID="txtToDate" name="txtToDate" runat="server" CssClass="form-control datetimepicker-input" placeholder="To Date" data-date-format="yyyy/MM/dd" data-target="#reservationdate2"></asp:TextBox>
                                                <div class="input-group-append" id="lblToDate" runat="server" data-target="#reservationdate2" data-toggle="datetimepicker">
                                                    <span class="input-group-text"><i class="fa fa-calendar-alt text-danger" id="icontxtToDate"></i></span>
                                                </div>
                                            </div>

                                            <div class="form-group col-sm-6 col-md-3 col-lg-3">
                                                <asp:Button ID="btnRefresh" runat="server" CssClass="btn btn-primary" Text="Refresh List" OnClick="btnRefresh_Click" OnClientClick="return fromDateToDateValidation();" type="button" />
                                                <asp:Button ID="btnExport" runat="server" CssClass="btn btn-primary" Text="Export" OnClick="btnExport_Click"  OnCLientClick="return startExport();" />
                                            </div>
                                        </div>
                                        
                                        <div class="tab-content p-0 table-responsive">
                                            <asp:Repeater runat="server" ID="rptRealTimeList">
                                                <HeaderTemplate>
                                                    <div class="table-responsive">
                                                        <table class="table border table-striped table-bordered table-hover mb-0 gridViewTable text-nowrap" id="applicationAuditTable" style="width: 100%">
                                                        <thead>

                                                            <tr>

                                                                <th>Date</th>
                                                                <th>Agent Id</th>
                                                                <th>Agent Name</th>

                                                                <th>Agent Location</th>
                                                                <th>Team Leader</th>
                                                                <%--<th>Query Type</th>--%>
                                                                <th>Worklist</th>
                                                                <th>Query Allocated</th>
                                                                <th>Query Completed #</th>
                                                                <th>Query Reassigned #</th>
                                                                <th>Query Paused #</th>
                                                                <th>Query Escalated #</th>
                                                                <th>Query Transferred #</th>

                                                                <th>Productivity Time Completed #</th>
                                                                <th>Productivity Time Paused #</th>
                                                                <th>Productivity Time Transferred #</th>
                                                                <th>Productivity Time Escalated #</th>
                                                                <th>Productivity Time Overall #</th>

                                                                <th>AHT Time Completed #</th>
                                                                <th>AHT Time Paused #</th>
                                                                <th>AHT Time Transferred #</th>
                                                                <th>AHT Time Escalated #</th>
                                                                <th>AHT Time Overall #</th>

                                                                <%--<th>Productive Time #</th>
                                                                <th>AHT #</th>--%>
                                                                <%--<th>LOB #</th>
                                                                <th>Airline #</th>--%>
                                                                <th>Idle Time (Sec.)</th>
                                                                <th>Non Productivity Time (Sec.)</th>

                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                </HeaderTemplate>
                                                <ItemTemplate>
                                                    <tr>
                                                        <asp:PlaceHolder runat="server">
                                                            <td><%# DataBinder.Eval(Container, "DataItem.DATE")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.AGENT_ID")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.AGENT_NAME")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.AGENT_LOCATION")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.TEAM_LEADER_NAME")%></td>
                                                            <%--<td><%# DataBinder.Eval(Container, "DataItem.JOB_TYPE")%></td>--%>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.FUNCTION")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.PNR_ALLOCATED")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.PNR_COMPLETED")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.PNR_REASSIGNED")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.PNR_PAUSED")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.PNR_ESCALATED")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.PNR_TRANSFER")%></td>

                                                            <td><%# DataBinder.Eval(Container, "DataItem.COMPLETED_Prodcutivity")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.PAUSED_Prodcutivity")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.TRANSFER_Prodcutivity")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.ESCALATED_Prodcutivity")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.Overall_Prodcutivity")%></td>

                                                            <td><%# DataBinder.Eval(Container, "DataItem.COMPLETED_AHT")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.PAUSED_AHT")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.TRANSFER_AHT")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.ESCALATED_AHT")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.Overall_AHT")%></td>


                                                            <%--<td><%# DataBinder.Eval(Container, "DataItem.PRODUCTIVE_TIME")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.AHT")%></td>--%>
                                                            <%--<td><%# DataBinder.Eval(Container, "DataItem.LOB")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.AIRLINE")%></td>--%>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.IDLE_TIME")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.NON_PRODUCTIVITY_TIME")%></td>
                                                        </asp:PlaceHolder>
                                                    </tr>
                                                </ItemTemplate>
                                                <FooterTemplate>
                                                    </tbody>
                                   </table>
                                                    </div>
                                                </FooterTemplate>
                                            </asp:Repeater>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.card-body -->
                            </div>
                        </div>
                        <!-- /.col-->
                    </div>
                    <!-- /.row -->
                    <!-- /.container-fluid -->
                </section>
                <!-- /.content -->
                <%--<div style="padding-top:30px">
       
            <asp:Table runat="server">
                <asp:TableRow>
                    
                    <asp:TableCell>
                        <label runat="server" >Start Date</label>
                          <asp:TextBox runat="server" ID="txtStartDate"></asp:TextBox>
                        
                         <ajaxToolkit:CalendarExtender ID="CalendarExtender2" TargetControlID="txtStartDate"  runat="server" />
                          <asp:ImageButton runat="server"  ID="ImageButton1" ImageUrl="~/Images/Imagebutton.ico" Width="40px" Height="40px" ImageAlign="Bottom"/>
                    </asp:TableCell>

                     <asp:TableCell>
                          <label runat="server" >End Date</label>
                          <asp:TextBox runat="server" ID="txtEndDate"></asp:TextBox>
                        
                         <ajaxToolkit:CalendarExtender ID="CalendarExtender1" TargetControlID="txtEndDate"  runat="server" />
                          <asp:ImageButton runat="server"  ID="imgPopup" ImageUrl="~/Images/Imagebutton.ico" Width="40px" Height="40px" ImageAlign="Bottom"/>
                       
                    </asp:TableCell>

                    <asp:TableCell>
                          <asp:Button ID="btnSearch" Text="Search" OnClick="btnSearch_Click" runat="server" />
                    </asp:TableCell>
                </asp:TableRow>
            </asp:Table>


        </div>--%>
            </div>
            <script type="text/javascript">
                $(window).on('load', function () {
                    $('#preloader').fadeOut('slow');
                });
                $(document).ready(function () {
                    if (typeof (Sys) != "undefined") {
                        var prm = Sys.WebForms.PageRequestManager.getInstance();
                        prm.add_endRequest(function () {
                            $('#reservationdate, #reservationdate2').datetimepicker({
                                format: 'L'
                            });
                        })
                    };
                    //Date picker
                    $('#reservationdate, #reservationdate2').datetimepicker({
                        format: 'L'
                    });

                });
            var exportTimer = null;
            var attemptCounter = 0;
            function startExport() {
                // Show the overlay and loader                
                var loader = document.getElementById('exportLoader');
                if (loader) {
                    loader.style.setProperty('display', 'flex', 'important');
                }
                attemptCounter = 0;
                if (exportTimer) {
                    clearInterval(exportTimer);
                    exportTimer = null;
                }
                exportTimer = setInterval(function () {
                    attemptCounter++;
                    if (attemptCounter >= 30) {
                        clearInterval(exportTimer);
                        exportTimer = null;
                        var targetLoader = document.getElementById('exportLoader');
                        if (targetLoader) {                           
                            targetLoader.style.setProperty('display', 'none', 'important');
                        }
                        return;
                    }
                    var cookies = document.cookie.split(';');
                    for (var i = 0; i < cookies.length; i++) {                       
                        var cookie = cookies[i].trim();                      
                        if (cookie.indexOf("ExportDownloadToken=") !== -1 || cookie.indexOf("ExportDownloadComplete=") !== -1) {
                            clearInterval(exportTimer);
                            // Hide the overlay when download finishes
                            var targetLoader = document.getElementById('exportLoader');
                            if (targetLoader) {                               
                                targetLoader.style.setProperty('display', 'none', 'important');
                            }
                            // Remove the completion cookie
                            document.cookie = "ExportDownloadToken=; Max-Age=0; path=/; SameSite=Lax";
                            document.cookie = "ExportDownloadComplete=; Max-Age=0; path=/; SameSite=Lax";
                            break;
                        }
                    }
                }, 500);
                setTimeout(function () {
                    var targetLoader = document.getElementById('exportLoader');
                    if (targetLoader) {                        
                        targetLoader.style.setProperty('display', 'none', 'important');
                    }
                }
                    , 4000);
                return true;
            }
            </script>
        </ContentTemplate>
  <Triggers>
      <asp:PostBackTrigger ControlID="btnExport" />
  </Triggers>
    </asp:UpdatePanel>
    <div id="exportLoader" style="display:none;position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.3);z-index:9999;justify-content:center;align-items:center;">
            <div  style="background:rgba(255,255,255,0.8);padding:10px;border-radius:5px;transform:translate(-50%,-50%); z-index:999;text-align:center;">"         
            <img src="malkom-static-assets/common/images/Loader.gif"
                 alt="Loading..." />
            <br />
            <span>Please wait...</span>
        </div>
        </div>
 <asp:UpdateProgress ID="UpdateProgress1" runat="server" AssociatedUpdatePanelID="updPanel">
     <ProgressTemplate>
         <div id="overlayBlocker"
             style="position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background-color: rgba(0,0,0,0.3); z-index: 998;">
         </div>
         <div style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 999; background: rgba(255, 255, 255, 0.8); padding: 10px; border-radius: 5px; text-align: center;">
             <img src="malkom-static-assets/common/images/Loader.gif" alt="Loading..." />
             <br />
             <span>Please wait...</span>
         </div>
     </ProgressTemplate>
 </asp:UpdateProgress>
</asp:Content>
