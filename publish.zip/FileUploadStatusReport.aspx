﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="FileUploadStatusReport.aspx.cs" MasterPageFile="~/masterPage.Master" Inherits="FCTG_Web.FileUploadStatusReport" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="mainBodyContent" runat="server">
    <asp:ScriptManager runat="server"></asp:ScriptManager>
    <asp:UpdatePanel ID="updPanel" runat="server">
        <ContentTemplate>
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <div class="content-header d-none">
                    <div class="container-fluid">
                        <div class="row mb-2">
                            <div class="col-sm-6">
                                <h1 class="m-0 pageTitle">Worklist Report</h1>
                            </div>
                            <!-- /.col -->
                          <%--  <div class="col-sm-6">
                                <ol class="breadcrumb float-sm-right">
                                    <li class="breadcrumb-item active">Report</li>
                                    <li class="breadcrumb-item active">Worklist Productivity Daily Report</li>
                                </ol>
                            </div>--%>
                            <!-- /.col -->
                        </div>
                        <!-- /.row -->
                    </div>
                    <!-- /.container-fluid -->
                </div>
                <!-- /.content-header -->

                <!-- Main content -->
                <section class="content">
                    <div class="container-fluid">
                        <!-- Small boxes (Stat box) -->
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h3 class="card-title font-weight-bold">
                                            <i class="fas fa-chart-pie mr-1"></i>
                                            File Upload Status Report</h3>
                                    </div>
                                    <!-- /.card-header -->
                                    <div class="card-body">
                                        <div class="form-row">
                                             <div class="input-group date form-group col-sm-6 col-md-3 col-lg-3" id="reservationdate1" data-target-input="nearest">
                                             <asp:DropDownList ID="ddl_Function" runat="server" placeholder="Select Worklist" CssClass="form-control">
                                             </asp:DropDownList>
                                             </div>
                                            <div class="input-group datepicker form-group col-sm-6 col-md-2 col-lg-2" id="reservationdate" data-target-input="nearest">
                                                <asp:TextBox type="text" ID="txtFromDate" name="txtFromDate" runat="server" CssClass="form-control datetimepicker-input" placeholder="From Date" data-date-format="yyyy/MM/dd" data-target="#reservationdate"></asp:TextBox>
                                                <div class="input-group-append" id="lblFromDate" runat="server" data-target="#reservationdate" data-toggle="datetimepicker">
                                                    <span class="input-group-text"><i class="fa fa-calendar-alt text-danger" id="icontxtFromDate"></i></span>
                                                </div>
                                            </div>
                                            <div class="input-group datepicker form-group col-sm-6 col-md-2 col-lg-2" id="reservationdate2" data-target-input="nearest">
                                                <asp:TextBox type="text" ID="txtToDate" name="txtToDate" runat="server" CssClass="form-control datetimepicker-input" placeholder="To Date" data-date-format="yyyy/MM/dd" data-target="#reservationdate2"></asp:TextBox>
                                                <div class="input-group-append" id="lblToDate" runat="server" data-target="#reservationdate2" data-toggle="datetimepicker">
                                                    <span class="input-group-text"><i class="fa fa-calendar-alt text-danger" id="icontxtToDate"></i></span>
                                                </div>
                                            </div>
                                            <div class="form-group col-sm-6 col-md-3 col-lg-3">
                                                <asp:Button ID="btnRefresh" runat="server" CssClass="btn btn-primary" Text="Refresh List" OnClick="btnRefresh_Click"  OnClientClick="return fromDateToDateValidation();" type="button" />
                                                <asp:Button ID="btnExport" runat="server" CssClass="btn btn-primary" Text="Export" onclick="btnExport_Click" />
                                            </div>
                                        </div>
                                        
                                        <div class="tab-content p-0 table-responsive">
                                            <asp:Repeater runat="server" ID="rptRealTimeList">
                                                <HeaderTemplate>
                                                    <div class="table-responsive">
                                                        <table class="table border table-striped table-bordered table-hover mb-0 gridViewTable text-nowrap" id="applicationAuditTable" style="width: 100%">
                                                        <thead>
                                                            <tr>
                                                                <th>FILE DATA SOURCE</th>
                                                                <th>FILE RECEIVED DATE</th>
                                                                <%--<th>Query Type</th>--%>

                                                                <th>FILE NAME</th>
                                                                <th>LOAD START DATE</th>

                                                                <th>LOAD END DATE</th>
                                                                <th>RECORD LOAD COUNT</th>
                                                                <th>RECORD ERROR COUNT</th>
                                                                <th>RECORD SKIP COUNT</th>
                                                                 
                                                                <th>STATUS</th>
                                                                <th>USER NAME</th>
                                                                <th>ERROR LOG</th>
                                                                <%--<th>LOB #</th>--%>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                </HeaderTemplate>
                                                <ItemTemplate>
                                                    <tr>
                                                        <asp:PlaceHolder runat="server">
                                                            <%--<td><%# Container.ItemIndex + 1 %></td>--%>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.FIleDataSource")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.FileReceivedDate")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.FileName")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.LoadStartDate")%></td>

                                                            <%--<td><%# DataBinder.Eval(Container, "DataItem.JOB_TYPE")%></td>--%>

                                                            <td><%# DataBinder.Eval(Container, "DataItem.LoadEndDate")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.RecordLoadCount")%></td> 
                                                                                                                  
                                                            <td><%# DataBinder.Eval(Container, "DataItem.RecordErrorCount ")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.RecordSkipCount")%></td>
                                                             <td><%# DataBinder.Eval(Container, "DataItem.Status")%></td>

                                                             <td><%# DataBinder.Eval(Container, "DataItem.UserName")%></td>                                                            
                                                             
                                                            <td><%# DataBinder.Eval(Container, "DataItem.ErrorLog")%></td>

                                                        </asp:PlaceHolder>
                                                    </tr>
                                                </ItemTemplate>
                                                <FooterTemplate>
                                                    </tbody>
                                   </table>
                                                    </div>
                                                </FooterTemplate>
                                            </asp:Repeater>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.card-body -->
                            </div>
                        </div>
                        <!-- /.col-->
                    </div>

                    <!-- /.row -->
                    <!-- /.container-fluid -->
                </section>
                <!-- /.content -->
            </div>
            <script type="text/javascript">
                $(window).on('load', function () {
                    $('#preloader').fadeOut('slow');
                });
                $(document).ready(function () {
                    if (typeof (Sys) != "undefined") {
                        var prm = Sys.WebForms.PageRequestManager.getInstance();
                        prm.add_endRequest(function () {
                            $('#reservationdate, #reservationdate2').datetimepicker({
                                format: 'L'
                            });
                        })
                    };
                    //Date picker
                    $('#reservationdate, #reservationdate2').datetimepicker({
                        format: 'L'
                    });

                });
            </script>
        </ContentTemplate>
    </asp:UpdatePanel>
</asp:Content>

