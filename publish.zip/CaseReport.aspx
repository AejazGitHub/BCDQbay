﻿<%@ Page Title="" Language="C#" MasterPageFile="~/masterPage.Master" AutoEventWireup="true" EnableViewState="true" CodeBehind="CaseReport.aspx.cs" Inherits="FCTG_WEB.CaseReport" %>

<asp:Content ID="Content2" ContentPlaceHolderID="mainBodyContent" runat="server">
    <asp:ScriptManager runat="server"></asp:ScriptManager>
    <asp:UpdatePanel ID="updPanel" runat="server">
        <ContentTemplate>
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <div class="content-header d-none">
                    <div class="container-fluid">
                        <div class="row mb-2">
                            <div class="col-sm-6">
                                <h1 class="m-0 pageTitle">Case Report</h1>
                            </div>
                            <!-- /.col -->
                            <div class="col-sm-6">
                                <ol class="breadcrumb float-sm-right">
                                    <li class="breadcrumb-item active">Report</li>
                                    <li class="breadcrumb-item active">Case Report</li>
                                </ol>
                            </div>
                            <!-- /.col -->
                        </div>
                        <!-- /.row -->
                    </div>
                    <!-- /.container-fluid -->
                </div>
                <!-- /.content-header -->

                <!-- Main content -->
                <section class="content">
                    <div class="container-fluid">
                        <!-- Small boxes (Stat box) -->
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h3 class="card-title font-weight-bold">
                                            <i class="fas fa-chart-pie mr-1"></i>
                                            Case Report</h3>
                                    </div>
                                    <!-- /.card-header -->
                                    <div class="card-body">
                                        <div class="form-row">
                                            <div class="input-group datepicker form-group col-sm-6 col-md-2 col-lg-2" id="reservationdate1" data-target-input="nearest">
                                                <asp:TextBox type="text" ID="txtFromDate" name="txtFromDate" runat="server" CssClass="form-control datetimepicker-input" placeholder="Inflow From Date" data-date-format="mm/dd/yyyy" data-target="#reservationdate1"></asp:TextBox>
                                                <div class="input-group-append" id="lblFromDate" runat="server" data-target="#reservationdate1" data-toggle="datetimepicker">
                                                    <span class="input-group-text"><i class="fa fa-calendar-alt text-danger" id="icontxtFromDate"></i></span>
                                                </div>
                                            </div>
                                            <div class="input-group datepicker form-group col-sm-6 col-md-2 col-lg-2" id="reservationdate2" data-target-input="nearest">
                                                <asp:TextBox type="text" ID="txtToDate" name="txtToDate" runat="server" CssClass="form-control datetimepicker-input" placeholder="Inflow To Date" data-date-format="mm/dd/yyyy" data-target="#reservationdate2"></asp:TextBox>
                                                <div class="input-group-append" id="lblToDate" runat="server" data-target="#reservationdate2" data-toggle="datetimepicker">
                                                    <span class="input-group-text"><i class="fa fa-calendar-alt text-danger" id="icontxtToDate"></i></span>
                                                </div>
                                            </div>

                                            <div class="input-group datepicker form-group col-sm-6 col-md-2 col-lg-2" id="reservationdate3" data-target-input="nearest">
                                                <asp:TextBox type="text" ID="txtCompleteFromDate" name="txtCompleteFromDate" runat="server" CssClass="form-control datetimepicker-input" placeholder="Completion From Date" data-date-format="mm/dd/yyyy" data-target="#reservationdate3"></asp:TextBox>
                                                <div class="input-group-append" id="lblCompleteFromDate" runat="server" data-target="#reservationdate3" data-toggle="datetimepicker">
                                                    <span class="input-group-text"><i class="fa fa-calendar-alt text-danger"></i></span>
                                                </div>
                                            </div>

                                            <div class="input-group datepicker form-group col-sm-6 col-md-2 col-lg-2" id="reservationdate4" data-target-input="nearest">
                                                <asp:TextBox type="text" ID="txtCompleteToDate" name="txtCompleteToDate" runat="server" CssClass="form-control datetimepicker-input" placeholder="Completion To Date" data-date-format="mm/dd/yyyy" data-target="#reservationdate4"></asp:TextBox>
                                                <div class="input-group-append" id="lblCompleteToDate" runat="server" data-target="#reservationdate4" data-toggle="datetimepicker">
                                                    <span class="input-group-text"><i class="fa fa-calendar-alt text-danger" id="icontxtActionToDate"></i></span>
                                                </div>
                                            </div>

                                            <div class="form-group col-sm-6 col-md-2 col-lg-2">
                                                <asp:Button ID="btnRefresh" runat="server" CssClass="btn btn-primary" Text="Refresh List" OnClick="btnRefreshList_Click" OnClientClick="return Validation();" />
                                                <asp:Button ID="btnExport" runat="server" CssClass="btn btn-primary" OnClick="btnExport_Click" Text="Export"  OnCLientClick="return startExport();" />
                                            </div>
                                        </div>

                                        
                                        <div class="tab-content p-0">
                                            <asp:Repeater runat="server" ID="rptPnrCase" OnItemCommand="rptCaseReportList_ItemCommand">
                                                <HeaderTemplate>
                                                    <div class="table-responsive">
                                                        <table class="table border table-striped table-bordered table-hover mb-0 gridViewTable text-nowrap" id="applicationAuditTable" style="width: 100%">
                                                            <thead>
                                                                <tr>
                                                                    <th>#</th>
                                                                    <th style="display: none"></th>
                                                                    <th>Case Type</th>
                                                                    <th>Case Number</th>
                                                                    <th>From Recipient</th>
                                                                    <th>To Recipient</th>
                                                                    <th>Worklist</th>
                                                                    <th>Received Date</th>
                                                                    <th>Subject</th>
                                                                    <th>First Assigned At</th>
                                                                    <th>First Started At</th>
                                                                    <th>Completed At</th>
                                                                    <th>Assigned To</th>
                                                                    <th>Completed By</th>
                                                                    <th>Productive Time</th>
                                                                    <th>Paused Time</th>
                                                                    <th>Disposition Comment</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                </HeaderTemplate>

                                                <ItemTemplate>
                                                    <tr>
                                                        <td><%# Container.ItemIndex + 1 %></td> 
                                                        <td style="display: none">
                                                  <asp:LinkButton runat="server" CssClass="action-btn edit-btn"  ID="btnEdit" CommandName="Edit" ToolTip="Reassign Job" CommandArgument='<%#Eval("JOB_REF") %>'><i class="fa fa-arrow-circle-left"></i></asp:LinkButton>
                                                          
                                                    </td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.CASE_TYPE")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.CASE_NUMBER")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.FROM_RECIPIENT")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.TO_RECIPIENT")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.FUNCTION_NAME")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.RECEIVED_DATE")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.SUBJECT")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.FIRST_ASSIGNED_AT")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.FIRST_STARTED_AT")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.COMPLETED_AT")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.ASSIGNED_TO")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.COMPLETED_BY")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.PRODUCTIVE_TIME")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.PAUSED_TIME")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.DISPOSITION_COMMENT")%></td>
                                                        <%--<td class="more"><%# DataBinder.Eval(Container, "DataItem.AGENT_LOCATION")%></td>--%>
                                                    </tr>
                                                </ItemTemplate>
                                                <FooterTemplate>
                                                    </tbody>
                        </table>
                                                    </div>
                                                </FooterTemplate>
                                            </asp:Repeater>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.card-body -->
                            </div>
                        </div>
                        <!-- /.col-->
                    </div>
                    <!-- /.row -->
                    <!-- /.container-fluid -->
                </section>
                <!-- /.content -->
            </div>
             <div class="popUpWindow" runat="server" tabindex="-1" aria-labelledby="createGroupLabel" aria-hidden="true" id="ajqModalCenter">
     <div class="modal-dialog modal-lg modal-dialog-centered">
         <div class="modal-content">
             <div class="modal-header p-2">
                 <h5 class="modal-title" id="exampleModalToggleLabel">
                     <asp:Button runat="server" CssClass="btn btn-primary" ID="btnRefreshAgentList" data-bs-target="#exampleModalToggle2" data-bs-toggle="modal" data-bs-dismiss="modal" Text="Refresh List" OnClick="btnRefreshAgentList_Click" />
                 </h5>
                 <asp:LinkButton type="button" ID="btnCloseFirstPopUp" runat="server" class="close" OnClick="btnCloseFirstPopUp_Click"><span aria-hidden="true">&times;</span></asp:LinkButton>
             </div>

             <div class="modal-body p-2">
                 <%--   Show a second modal and hide this one with the button below.--%>
                 <asp:Repeater runat="server" ID="rptAvailableAgentList" OnItemCommand="rptAvailableAgentList_ItemCommand">
                     <HeaderTemplate>
                         <table class="table table-bordered table-striped mb-0 gridViewTable" id="applicationAuditTable" style="width: 100%">
                             <thead>
                                 <tr>
                                     <th>#</th>
                                     <th></th>
                                     <th>User ID</th>
                                     <th>User Name</th>
                                     <th>Current Status</th>
                                     <%--<th class="border-right">Identification Text</th>--%>
                                 </tr>
                             </thead>
                             <tbody>
                     </HeaderTemplate>
                     <ItemTemplate>
                         <tr>
                             <td><%# Container.ItemIndex + 1 %></td>
                             <td>
                                 <span></span><asp:LinkButton runat="server" CssClass="action-btn edit-btn" ID="btnAvailableAgentEdit" CommandName="Edit" ToolTip="Select Agent" CommandArgument='<%#Eval("USER_REF") %>'><i class="fa fa-arrow-circle-left"></i></asp:LinkButton>
                             </td>
                             <td class="more"><%# DataBinder.Eval(Container, "DataItem.AGENT_ID")%></td>
                             <td class="more"><%# DataBinder.Eval(Container, "DataItem.AGENT_NAME")%></td>
                             <td class="more"><%# DataBinder.Eval(Container, "DataItem.CURRENT_STATUS")%></td>
                         </tr>
                     </ItemTemplate>
                     <FooterTemplate>
                         </tbody>
                    </table>
                     </FooterTemplate>
                 </asp:Repeater>
             </div>
             <div class="modal-footer p-1">
                 <%--<asp:Button runat="server" CssClass="btn btn-primary" ID="btnFirstPopup" data-bs-target="#exampleModalToggle2" data-bs-toggle="modal" data-bs-dismiss="modal" Text="Open second modal" OnClick="btnFirstPopup_Click" />--%>
             </div>
         </div>
     </div>
 </div>

 <div class="popUpWindow" runat="server"  aria-hidden="true" txtpnr-labelledby="createGroupLabel2" tabindex="-1" id="ajqModalCenter2">
     <div class="modal-dialog modal-dialog-centered">
         <div class="modal-content">
             <div class="modal-header p-2">
                 <h5 class="modal-title" id="exampleModalToggleLabel2">Comments</h5>
                 <asp:LinkButton type="button" ID="btnCloseSecondPopUp" runat="server" class="close" OnClick="btnCloseSecondPopUp_Click"><span aria-hidden="true">&times;</span></asp:LinkButton>
             </div>
             <div class="modal-body p-2">
                 Please enter your comments for reassignment:
                 <asp:TextBox type="text" ID="txtComments" name="txtPNR" runat="server" CssClass="form-control form-control-sm" placeholder="Comments" MaxLength="50"></asp:TextBox>
             </div>
             <div class="modal-footer p-1">
                 <asp:Button runat="server" ID="btnOk" CssClass="btn btn-primary" data-bs-target="#exampleModalToggle" data-bs-toggle="modal" data-bs-dismiss="modal" Text="OK" OnClientClick="return CheckComments();" OnClick="btnOk_Click" />
                 <asp:Button runat="server" ID="btnCancel" CssClass="btn btn-yellow" data-bs-target="#exampleModalToggle" data-bs-toggle="modal" data-bs-dismiss="modal" Text="Cancel" OnClick="btnCloseSecondPopUp_Click" />
             </div>
         </div>
     </div>
 </div>
            <script type="text/javascript">

                $(window).on('load', function () {
                    $('#preloader').fadeOut('slow');
                });
                $(document).ready(function () {
                    if (typeof (Sys) != "undefined") {
                        var prm = Sys.WebForms.PageRequestManager.getInstance();
                        prm.add_endRequest(function () {
                            $('#reservationdate1, #reservationdate2,#reservationdate3,#reservationdate4').datetimepicker({
                                format: 'L'
                            });
                        })
                    };
                    //Date picker
                    $('#reservationdate1, #reservationdate2,#reservationdate3,#reservationdate4').datetimepicker({
                        format: 'L'
                    });
                });

                function Validation() {
                    $('.error').remove();
                    var flag = true;
                    var ifd = $('#<%=txtFromDate.ClientID%>').val();
                    var itd = $('#<%=txtToDate.ClientID%>').val();
                    var cfd = $('#<%=txtCompleteFromDate.ClientID%>').val();
                    var ctd = $('#<%=txtCompleteToDate.ClientID%>').val();

                    if (ifd == "" && itd == "" && cfd == "" && ctd == "") {
                        //alert("Please select inflow or completion date range or PNR to proceed!");
                        $('#<%=txtFromDate.ClientID%>,#<%=txtToDate.ClientID%>').addClass('border border-danger');
                        $('#<%=lblFromDate.ClientID%>').after('<div class="text-danger mt-2 d-block error">Please enter Inflow From Date</div>');
                        $('#<%=lblToDate.ClientID%>').after('<div class="text-danger mt-2 d-block error">Please enter Inflow To Date</div>');

                        $('#<%=txtCompleteFromDate.ClientID%>,#<%=txtCompleteToDate.ClientID%>').addClass('border border-danger');
                        $('#<%=lblCompleteFromDate.ClientID%>').after('<div class="text-danger mt-2 d-block error">Please enter Completion From Date</div>');
                        $('#<%=lblCompleteToDate.ClientID%>').after('<div class="text-danger mt-2 d-block error">Please enter Completion To Date</div>');
                        flag = false;
                    }
                    if (ifd != '') {
                        if (Date.parse(ifd) > Date.parse(itd)) {
                            $('.error').remove();
                            $('input').removeClass('border border-success border-danger');
                            $('#<%=txtToDate.ClientID%>').addClass('border-danger');
                            $('#<%=lblToDate.ClientID%>').siblings().remove('#err');
                            $('#<%=lblToDate.ClientID%>').after('<div id="err" class="text-danger mt-2 d-block error">To Date should be greater than From date</div>');
                            $('#<%=txtFromDate.ClientID%>').removeClass('border-danger').addClass('border-success');
                            flag = false;
                        } else {
                            $('#<%=txtToDate.ClientID%>').removeClass('border-danger');
                            $('#<%=lblToDate.ClientID%>').remove('#err');
                        }
                    }
                    if (cfd != '') {
                        if (Date.parse(cfd) > Date.parse(ctd)) {
                            $('.error').remove();
                            $('input').removeClass('border border-success border-danger');
                            $('#<%=txtCompleteToDate.ClientID%>').addClass('border-danger');
                            $('#<%=lblCompleteToDate.ClientID%>').siblings().remove('#err');
                            $('#<%=lblCompleteToDate.ClientID%>').after('<div id="err" class="text-danger mt-2 d-block error">Completion To Date should be greater than Completion From date</div>');
                            $('#<%=txtCompleteFromDate.ClientID%>').removeClass('border-danger').addClass('border-success');
                            flag = false;
                        } else {
                            $('#<%=txtCompleteToDate.ClientID%>').removeClass('border-danger');
                            $('#<%=lblCompleteToDate.ClientID%>').remove('#err');
                        }
                    }
                    if (ifd != "" && itd == "") {
                        $('.error').remove();
                        $('input').removeClass('border border-success border-danger');
                        //alert("Please select inflow date range to proceed!");
                        $('#<%=txtFromDate.ClientID%>').removeClass('border-danger').addClass('border-success');
                        $('#<%=txtToDate.ClientID%>').addClass('border border-danger');
                        $('#<%=lblToDate.ClientID%>').after('<div class="text-danger mt-2 d-block error">Please enter Inflow To Date</div>');
                        $('#<%=txtCompleteFromDate.ClientID%>,#<%=txtCompleteToDate.ClientID%>').removeClass('border border-danger');
                        flag = false;
                    }
                    if (ifd == "" && itd != "") {
                        $('.error').remove();
                        $('input').removeClass('border border-success border-danger');
                        //alert("Please select inflow date range to proceed!");
                        $('#<%=txtToDate.ClientID%>').removeClass('border-danger').addClass('border-success');
                        $('#<%=txtFromDate.ClientID%>').addClass('border border-danger');
                        $('#<%=lblFromDate.ClientID%>').after('<div class="text-danger mt-2 d-block error">Please enter Inflow To Date</div>');
                        $('#<%=txtCompleteFromDate.ClientID%>,#<%=txtCompleteToDate.ClientID%>').removeClass('border border-danger');
                        flag = false;
                    }
                    if (cfd != "" && ctd == "") {
                        $('.error').remove();
                        $('input').removeClass('border border-success border-danger');
                        //alert("Please select action date range to proceed!");
                        $('#<%=txtCompleteFromDate.ClientID%>').removeClass('border-danger').addClass('border-success');
                        $('#<%=txtCompleteToDate.ClientID%>').addClass('border border-danger');
                        $('#<%=lblCompleteToDate.ClientID%>').after('<div class="text-danger mt-2 d-block error">Please enter Completion To Date</div>');
                        $('#<%=txtFromDate.ClientID%>,#<%=txtToDate.ClientID%>').removeClass('border border-danger');
                        flag = false;
                    }
                    if (cfd == "" && ctd != "") {
                        $('.error').remove();
                        $('input').removeClass('border border-success border-danger');
                        //alert("Please select action date range to proceed!");
                        $('#<%=txtCompleteToDate.ClientID%>').removeClass('border-danger').addClass('border-success');
                        $('#<%=txtCompleteFromDate.ClientID%>').addClass('border border-danger');
                        $('#<%=lblCompleteFromDate.ClientID%>').after('<div class="text-danger mt-2 d-block error">Please enter Completion To Date</div>');
                        $('#<%=txtFromDate.ClientID%>,#<%=txtToDate.ClientID%>').removeClass('border border-danger');
                        flag = false;
                    }
                    return flag;
}

            var exportTimer = null;
            var attemptCounter = 0;
            function startExport() {
                // Show the overlay and loader
               
                var loader = document.getElementById('exportLoader');

                if (loader) {
                    loader.style.setProperty('display', 'flex', 'important');
                }
                attemptCounter = 0;
                if (exportTimer) {
                    clearInterval(exportTimer);
                    exportTimer = null;
                }

                exportTimer = setInterval(function () {
                    attemptCounter++;

                    if (attemptCounter >= 30) {
                        clearInterval(exportTimer);
                        exportTimer = null;

                        var targetLoader = document.getElementById('exportLoader');
                        if (targetLoader) {
                          
                            targetLoader.style.setProperty('display', 'none', 'important');
                        }
                        return;
                    }

                    var cookies = document.cookie.split(';');

                    for (var i = 0; i < cookies.length; i++) {                        
                        var cookie = cookies[i].trim();                      
                        if (cookie.indexOf("ExportDownloadToken=") !== -1 || cookie.indexOf("ExportDownloadComplete=") !== -1) {
                           
                            clearInterval(exportTimer);

                            // Hide the overlay when download finishes

                            var targetLoader = document.getElementById('exportLoader');
                            if (targetLoader) {                               
                                targetLoader.style.setProperty('display', 'none', 'important');
                            }

                            // Remove the completion cookie
                            document.cookie = "ExportDownloadToken=; Max-Age=0; path=/; SameSite=Lax";
                            document.cookie = "ExportDownloadComplete=; Max-Age=0; path=/; SameSite=Lax";
                            break;
                        }
                    }

                }, 500);

                setTimeout(function () {

                    var targetLoader = document.getElementById('exportLoader');
                    if (targetLoader) {                       
                        targetLoader.style.setProperty('display', 'none', 'important');
                    }
                }
                    , 4000);

                return true;
            }
            </script>
        </ContentTemplate>
    <Triggers>
        <asp:PostBackTrigger ControlID="btnExport" />
    </Triggers>
    </asp:UpdatePanel>

       <div id="exportLoader" style="display:none;position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.3);z-index:9999;justify-content:center;align-items:center;">

           <div  style="background:rgba(255,255,255,0.8);padding:10px;border-radius:5px;transform:translate(-50%,-50%); z-index:999;text-align:center;">"         
           
           <img src="malkom-static-assets/common/images/Loader.gif"
                alt="Loading..." />
           <br />
           <span>Please wait...</span>
       </div>
       </div>
    
    <asp:UpdateProgress ID="UpdateProgress1" runat="server" AssociatedUpdatePanelID="updPanel">
        <ProgressTemplate>
            <div id="overlayBlocker"
                style="position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background-color: rgba(0,0,0,0.3); z-index: 998;">
            </div>
            <div style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 999; background: rgba(255, 255, 255, 0.8); padding: 10px; border-radius: 5px; text-align: center;">
                <img src="malkom-static-assets/common/images/Loader.gif" alt="Loading..." />
                <br />
                <span>Please wait...</span>
            </div>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <!-- /.content-wrapper -->
</asp:Content>
