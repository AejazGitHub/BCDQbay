﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="functionProductivityMonthlyReport.aspx.cs" MasterPageFile="~/masterPage.Master" Inherits="FCTG_Web.functionProductivityMonthlyReport" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="mainBodyContent" runat="server">
    <asp:ScriptManager runat="server"></asp:ScriptManager>
    <asp:UpdatePanel ID="updPanel" runat="server">
        <ContentTemplate>
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <div class="content-header d-none">
                    <div class="container-fluid">
                        <div class="row mb-2">
                            <div class="col-sm-6">
                                <h1 class="m-0 pageTitle">Worklist Productivity Monthly Report</h1>
                            </div>
                            <!-- /.col -->
                           <%-- <div class="col-sm-6">
                                <ol class="breadcrumb float-sm-right">
                                    <li class="breadcrumb-item active">Report</li>
                                    <li class="breadcrumb-item active">Function Productivity Monthly Report</li>
                                </ol>
                            </div>--%>
                            <!-- /.col -->
                        </div>
                        <!-- /.row -->
                    </div>
                    <!-- /.container-fluid -->
                </div>
                <!-- /.content-header -->

                <!-- Main content -->
                <section class="content">
                    <div class="container-fluid">
                        <!-- Small boxes (Stat box) -->
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h3 class="card-title font-weight-bold">
                                            <i class="fas fa-chart-pie mr-1"></i>
                                            Worklist Productivity Monthly Report</h3>
                                    </div>

                                    <!-- /.card-header -->
                                    <div class="card-body">
                                        <div class="form-row">
                                             <div class="input-group date form-group col-sm-6 col-md-3 col-lg-3" id="reservationdate4" data-target-input="nearest">
                                                 <asp:DropDownList ID="ddl_Function" runat="server" placeholder="Select Worklist" CssClass="form-control">
                                                 </asp:DropDownList>
                                             </div>
                                            <div class="input-group datepicker form-group col-sm-6 col-md-2 col-lg-2" id="reservationdate" data-target-input="nearest">
                                                <asp:TextBox type="text" ID="txtFromDate" name="txtFromDate" runat="server" CssClass="form-control datetimepicker-input" placeholder="From Date" data-date-format="yyyy/MM/dd" data-target="#reservationdate"></asp:TextBox>
                                                <div class="input-group-append" id="lblFromDate" runat="server" data-target="#reservationdate" data-toggle="datetimepicker">
                                                    <span class="input-group-text"><i class="fa fa-calendar-alt text-danger" id="icontxtFromDate"></i></span>
                                                </div>
                                            </div>
                                            <div class="input-group datepicker form-group col-sm-6 col-md-2 col-lg-2" id="reservationdate2" data-target-input="nearest">
                                                <asp:TextBox type="text" ID="txtToDate" name="txtToDate" runat="server" CssClass="form-control datetimepicker-input" placeholder="To Date" data-date-format="yyyy/MM/dd" data-target="#reservationdate2"></asp:TextBox>
                                                <div class="input-group-append" id="lblToDate" runat="server" data-target="#reservationdate2" data-toggle="datetimepicker">
                                                    <span class="input-group-text"><i class="fa fa-calendar-alt text-danger" id="icontxtToDate"></i></span>
                                                </div>
                                            </div>

                                            <div class="form-group col-sm-6 col-md-3 col-lg-3">
                                                <asp:Button ID="btnRefresh" runat="server" CssClass="btn btn-primary" Text="Refresh List" OnClick="btnRefresh_Click" OnClientClick="return fromDateToDateValidation();" type="button" />
                                                <asp:Button ID="btnExport" runat="server" CssClass="btn btn-primary" Text="Export" OnClick="btnExport_Click" OnCLientClick="return startExport();" />
                                            </div>
                                        </div>
                                        
                                        <div class="tab-content p-0 table-responsive">
                                            <asp:Repeater runat="server" ID="rptRealTimeList">
                                                <HeaderTemplate>
                                                    <div class="table-responsive">
                                                        <table class="table border table-striped table-bordered table-hover mb-0 gridViewTable text-nowrap" id="applicationAuditTable" style="width: 100%">
                                                            <thead>

                                                                <tr>
                                                                    <%--  <th>#</th>
                                                <th></th>--%>
                                                                    <th>Year</th>
                                                                    <th>Month </th>
                                                                    <th>Worklist</th>
                                                                    <%--<th>Query Type</th>--%>

                                                                    <th>Query Allocated</th>
                                                                    <th>Query Completed #</th>

                                                                    <th>Query Paused #</th>
                                                                    <th>Query Transfer #</th>

                                                                    <th>Productive Time #</th>
                                                                    <th>AHT #</th>
                                                                    <%--<th>LOB #</th>--%>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                </HeaderTemplate>
                                                <ItemTemplate>
                                                    <tr>
                                                        <asp:PlaceHolder runat="server">


                                                            <td><%# DataBinder.Eval(Container, "DataItem.YEAR")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.MONTH")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.PNR_FUNCTION")%></td>

                                                            <%--<td><%# DataBinder.Eval(Container, "DataItem.JOB_TYPE")%></td>--%>

                                                            <td><%# DataBinder.Eval(Container, "DataItem.PNR_ALLOCATED")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.PNR_COMPLETED")%></td>

                                                            <td><%# DataBinder.Eval(Container, "DataItem.PNR_PAUSED")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.PNR_TRANSFER")%></td>

                                                            <td><%# DataBinder.Eval(Container, "DataItem.PRODUCTIVE_TIME")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.AHT")%></td>
                                                            <%--<td><%# DataBinder.Eval(Container, "DataItem.LOB")%></td>--%>

                                                        </asp:PlaceHolder>
                                                    </tr>
                                                </ItemTemplate>
                                                <FooterTemplate>
                                                    </tbody>
                                   </table>
                                                    </div>
                                                </FooterTemplate>
                                            </asp:Repeater>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.card-body -->
                            </div>
                        </div>
                        <!-- /.col-->
                    </div>

                    <!-- /.row -->
                    <!-- /.container-fluid -->
                </section>
                <!-- /.content -->
                <%--<div style="padding-top:30px">
       
            <asp:Table runat="server">
                <asp:TableRow>
                    
                    <asp:TableCell>
                        <label runat="server" >Start Date</label>
                          <asp:TextBox runat="server" ID="txtStartDate"></asp:TextBox>
                        
                         <ajaxToolkit:CalendarExtender ID="CalendarExtender2" TargetControlID="txtStartDate"  runat="server" />
                          <asp:ImageButton runat="server"  ID="ImageButton1" ImageUrl="~/Images/Imagebutton.ico" Width="40px" Height="40px" ImageAlign="Bottom"/>
                    </asp:TableCell>

                     <asp:TableCell>
                          <label runat="server" >End Date</label>
                          <asp:TextBox runat="server" ID="txtEndDate"></asp:TextBox>
                        
                         <ajaxToolkit:CalendarExtender ID="CalendarExtender1" TargetControlID="txtEndDate"  runat="server" />
                          <asp:ImageButton runat="server"  ID="imgPopup" ImageUrl="~/Images/Imagebutton.ico" Width="40px" Height="40px" ImageAlign="Bottom"/>
                       
                    </asp:TableCell>

                    <asp:TableCell>
                          <asp:Button ID="btnSearch" Text="Search" OnClick="btnSearch_Click" runat="server" />
                    </asp:TableCell>
                </asp:TableRow>
            </asp:Table>


        </div>--%>
            </div>
            <script type="text/javascript">
                $(window).on('load', function () {
                    $('#preloader').fadeOut('slow');
                });
                $(document).ready(function () {
                    if (typeof (Sys) != "undefined") {
                        var prm = Sys.WebForms.PageRequestManager.getInstance();
                        prm.add_endRequest(function () {
                            $('#reservationdate, #reservationdate2').datetimepicker({
                                format: 'L'
                            });
                        })
                    };
                    //Date picker
                    $('#reservationdate, #reservationdate2').datetimepicker({
                        format: 'L'
                    });

                });

            var exportTimer = null;
            var attemptCounter = 0;
            function startExport() {
                // Show the overlay and loader
              
                var loader = document.getElementById('exportLoader');

                if (loader) {
                    loader.style.setProperty('display', 'flex', 'important');
                }
                attemptCounter = 0;
                if (exportTimer) {
                    clearInterval(exportTimer);
                    exportTimer = null;
                }

                exportTimer = setInterval(function () {
                    attemptCounter++;

                    if (attemptCounter >= 30) {
                        clearInterval(exportTimer);
                        exportTimer = null;

                        var targetLoader = document.getElementById('exportLoader');
                        if (targetLoader) {
                           
                            targetLoader.style.setProperty('display', 'none', 'important');
                        }
                        return;
                    }

                    var cookies = document.cookie.split(';');

                    for (var i = 0; i < cookies.length; i++) {
                       
                        var cookie = cookies[i].trim();                       
                        if (cookie.indexOf("ExportDownloadToken=") !== -1 || cookie.indexOf("ExportDownloadComplete=") !== -1) {
                           
                            clearInterval(exportTimer);

                            // Hide the overlay when download finishes

                            var targetLoader = document.getElementById('exportLoader');
                            if (targetLoader) {                               
                                targetLoader.style.setProperty('display', 'none', 'important');
                            }

                            // Remove the completion cookie
                            document.cookie = "ExportDownloadToken=; Max-Age=0; path=/; SameSite=Lax";
                            document.cookie = "ExportDownloadComplete=; Max-Age=0; path=/; SameSite=Lax";
                            break;
                        }
                    }

                }, 500);

                setTimeout(function () {

                    var targetLoader = document.getElementById('exportLoader');
                    if (targetLoader) {                      
                        targetLoader.style.setProperty('display', 'none', 'important');
                    }
                }
                    , 4000);

                return true;
            }
            </script>
        </ContentTemplate>
 

      <Triggers>
      <asp:PostBackTrigger ControlID="btnExport" />
      </Triggers>
    </asp:UpdatePanel>

    <div id="exportLoader" style="display:none;position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.3);z-index:9999;justify-content:center;align-items:center;">

        <div  style="background:rgba(255,255,255,0.8);padding:10px;border-radius:5px;transform:translate(-50%,-50%); z-index:999;text-align:center;">"         
            
        <img src="malkom-static-assets/common/images/Loader.gif"
                alt="Loading..." />
        <br />
        <span>Please wait...</span>
    </div>
    </div>


 <asp:UpdateProgress ID="UpdateProgress1" runat="server" AssociatedUpdatePanelID="updPanel">
     <ProgressTemplate>
         <div id="overlayBlocker"
             style="position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background-color: rgba(0,0,0,0.3); z-index: 998;">
         </div>
         <div style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 999; background: rgba(255, 255, 255, 0.8); padding: 10px; border-radius: 5px; text-align: center;">
             <img src="malkom-static-assets/common/images/Loader.gif" alt="Loading..." />
             <br />
             <span>Please wait...</span>
         </div>
     </ProgressTemplate>
 </asp:UpdateProgress>
</asp:Content>
