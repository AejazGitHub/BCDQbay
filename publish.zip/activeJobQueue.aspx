﻿<%@ Page Title="Active Job Queue" Language="C#" MasterPageFile="~/masterPage.Master" AutoEventWireup="true" CodeBehind="activeJobQueue.aspx.cs" Inherits="FCTG_WEB.activeJobQueue" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="mainBodyContent" runat="server">
    <asp:ScriptManager runat="server"></asp:ScriptManager>
    <asp:UpdatePanel ID="updPanel" runat="server">
        <ContentTemplate>
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <div class="content-header d-none">
                    <div class="container-fluid">
                        <div class="row mb-2">
                            <div class="col-sm-6">
                                <h1 class="m-0 pageTitle">Active Queries</h1>
                            </div>
                            <!-- /.col -->
                            <%--<div class="col-sm-6">
                                <ol class="breadcrumb float-sm-right">
                                    <li class="breadcrumb-item active">Report</li>
                                    <li class="breadcrumb-item active">Active Queries</li>
                                </ol>
                            </div>--%>
                            <!-- /.col -->
                        </div>
                        <!-- /.row -->
                    </div>
                    <!-- /.container-fluid -->
                </div>
                <!-- /.content-header -->

                <!-- Main content -->
                <section class="content">
                    <div class="container-fluid">
                        <!-- Small boxes (Stat box) -->
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h3 class="card-title font-weight-bold">
                                            <i class="fas fa-chart-pie mr-1"></i>
                                            Active Queries</h3>
                                    </div>
                                    <!-- /.card-header -->
                                    <div class="card-body">
                                        <div class="form-row">
                                            <div class="input-group date form-group col-sm-6 col-md-3 col-lg-3" id="reservationdate" data-target-input="nearest">
                                                <asp:DropDownList ID="ddl_Function" runat="server" placeholder="Select Worklist" CssClass="form-control">
                                                </asp:DropDownList>
                                            </div>
                                            <div class="input-group date d-flex form-group col-sm-6 col-md-3 col-lg-2" id="reservationdate2" data-target-input="nearest">
                                                <asp:TextBox type="text" ID="txtPNR" name="txtPNR" runat="server" CssClass="form-control" placeholder="Case Number" data-target="#reservationdate2"></asp:TextBox>
                                            </div>
                                            <div class="form-group col-sm-6 col-md-3 col-lg-3">
                                                <asp:Button ID="btnRefreshList" runat="server" CssClass="btn btn-primary" Text="Refresh List" OnClick="btnRefreshList_Click" />
                                                <asp:Button ID="btnExport" runat="server" CssClass="btn btn-primary" Text="Export" OnClick="btnExport_Click"  OnCLientClick="return startExport();" />
                                            </div>
                                        </div>
                                        
                                        <div class="tab-content p-0">
                                            <asp:Repeater runat="server" ID="rptAJQList" OnItemCommand="rptAJQList_ItemCommand">
                                                <HeaderTemplate>
                                                    <div class="table-responsive">
                                                        <table class="table border table-striped table-bordered table-hover mb-0 gridViewTable text-nowrap" id="applicationAuditTable" style="width: 100%">
                                                            <thead>
                                                                <tr>
                                                                    <th>#</th>
                                                                    <th></th>
                                                                    <th>Case Number</th>
                                                                    <th>Case Type</th>
                                                                    <th>Worklist</th>
                                                                    <th>Region</th>
                                                                    <th>Received Date</th>
                                                                  <%--  <th>From Recipient</th>
                                                                    <th>Subject</th>--%>
                                                                    <th>Priority</th>
                                                                    <th>Status</th>
                                                                    <th>In Status Since</th>
                                                                    <th>Assigned To</th>
                                                                    <th>Assignment At</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                </HeaderTemplate>
                                                <ItemTemplate>
                                                    <tr>
                                                        <td><%# Container.ItemIndex + 1 %></td>
                                                        <td>
                                                            <asp:LinkButton runat="server" CssClass="action-btn edit-btn" ID="btnEdit" CommandName="Edit" ToolTip="Reassign Job" CommandArgument='<%#Eval("PNR") %>'><i class="fa fa-arrow-circle-left"></i></asp:LinkButton>
                                                        </td>
                                                        <td><%# DataBinder.Eval(Container, "DataItem.RECORD_LOCATOR")%></td>
                                                        <td><%# DataBinder.Eval(Container, "DataItem.TYPE")%></td>
                                                        <td><%# DataBinder.Eval(Container, "DataItem.FUNCTION_NAME")%></td>
                                                        <td><%# DataBinder.Eval(Container, "DataItem.REGION")%></td>
                                                        <td><%# DataBinder.Eval(Container, "DataItem.EXTRACTION_TIME")%></td>
                                                        
                                                        <%--<td><%# DataBinder.Eval(Container, "DataItem.FROM_RECIPIENT")%></td>
                                                        <td><%# DataBinder.Eval(Container, "DataItem.SUBJECT")%></td>--%>
                                                       
                                                        <td><%# DataBinder.Eval(Container, "DataItem.PRIORITY_NO")%></td>
                                                        <td><%# DataBinder.Eval(Container, "DataItem.CURRENT_STATUS")%></td>
                                                       
                                                        <td><%# DataBinder.Eval(Container, "DataItem.IN_STATUS_SINCE")%></td>
                                                        <td><%# DataBinder.Eval(Container, "DataItem.ASSIGNED_TO")%></td>
                                                        <td><%# DataBinder.Eval(Container, "DataItem.ASSIGNEMENT_TIME")%></td>

                                                        <%--   <td>
                                        <asp:LinkButton runat="server" CssClass="pr-2" CssClass="action-btn edit-btn" ID="btnEdit" CommandName="Edit" ToolTip="Edit a record." CommandArgument='<%#Eval("Flight_Master_Key") %>'><i class="fa fa-pencil-alt"></i></asp:LinkButton>
                                    </td>--%>

                                                    </tr>
                                                </ItemTemplate>
                                                <FooterTemplate>
                                                    </tbody>
                                                    </table>
                                                    </div>
                                                </FooterTemplate>
                                            </asp:Repeater>
                                        </div>
                                        <asp:Label ID="lblRecordCount" Text="" runat="server"></asp:Label>
                                    </div>
                                </div>
                                <!-- /.card-body -->
                            </div>
                        </div>
                        <!-- /.col-->
                    </div>
                    <!-- /.row -->
                    <!-- /.container-fluid -->
                </section>
                <!-- /.content -->
                <div class="popUpWindow" runat="server" tabindex="-1" aria-labelledby="createGroupLabel" aria-hidden="true" id="ajqModalCenter">
                    <div class="modal-dialog modal-lg modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header p-2">
                                <h5 class="modal-title" id="exampleModalToggleLabel">
                                    <asp:Button runat="server" CssClass="btn btn-primary" ID="btnRefreshAgentList" data-bs-target="#exampleModalToggle2" data-bs-toggle="modal" data-bs-dismiss="modal" Text="Refresh List" OnClick="btnRefreshAgentList_Click" />
                                </h5>
                                <asp:LinkButton type="button" ID="btnCloseFirstPopUp" runat="server" class="close" OnClick="btnCloseSecondPopUp_Click"><span aria-hidden="true">&times;</span></asp:LinkButton>
                            </div>
                            <div class="modal-body p-2">
                                <%--   Show a second modal and hide this one with the button below.--%>
                                <asp:Repeater runat="server" ID="rptAvailableAgentList" OnItemCommand="rptAvailableAgentList_ItemCommand">
                                    <HeaderTemplate>
                                        <table class="table table-bordered table-striped mb-0 gridViewTable" id="applicationAuditTable" style="width: 100%">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th></th>
                                                    <th>User ID</th>
                                                    <th>User Name</th>
                                                    <th>Current Status</th>
                                                    <%--<th class="border-right">Identification Text</th>--%>
                                                </tr>
                                            </thead>
                                            <tbody>
                                    </HeaderTemplate>
                                    <ItemTemplate>
                                        <tr>
                                            <td><%# Container.ItemIndex + 1 %></td>
                                            <td>
                                                <asp:LinkButton runat="server" CssClass="action-btn edit-btn" ID="btnAvailableAgentEdit" CommandName="Edit" ToolTip="Select Agent" CommandArgument='<%#Eval("USER_REF") %>'><i class="fa fa-arrow-circle-left"></i></asp:LinkButton>
                                            </td>
                                            <td class="more"><%# DataBinder.Eval(Container, "DataItem.AGENT_ID")%></td>
                                            <td class="more"><%# DataBinder.Eval(Container, "DataItem.AGENT_NAME")%></td>
                                            <td class="more"><%# DataBinder.Eval(Container, "DataItem.CURRENT_STATUS")%></td>
                                        </tr>
                                    </ItemTemplate>
                                    <FooterTemplate>
                                        </tbody>
                                   </table>
                                    </FooterTemplate>
                                </asp:Repeater>
                            </div>
                            <div class="modal-footer p-1">
                                <%--<asp:Button runat="server" CssClass="btn btn-primary" ID="btnFirstPopup" data-bs-target="#exampleModalToggle2" data-bs-toggle="modal" data-bs-dismiss="modal" Text="Open second modal" OnClick="btnFirstPopup_Click" />--%>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="popUpWindow" runat="server" aria-hidden="true" txtpnr-labelledby="createGroupLabel2" tabindex="-1" id="ajqModalCenter2">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header p-2">
                                <h5 class="modal-title" id="exampleModalToggleLabel2">Comments</h5>
                                <asp:LinkButton type="button" ID="btnCloseSecondPopUp" runat="server" class="close" OnClick="btnCloseSecondPopUp_Click"><span aria-hidden="true">&times;</span></asp:LinkButton>
                            </div>
                            <div class="modal-body p-2">
                                Please enter your comments for reassignment:
                                <asp:TextBox type="text" ID="txtComments" name="txtPNR" runat="server" CssClass="form-control form-control-sm" placeholder="Comments" MaxLength="50"></asp:TextBox>
                            </div>
                            <div class="modal-footer p-1">
                                <asp:Button runat="server" ID="btnOk" CssClass="btn btn-primary" data-bs-target="#exampleModalToggle" data-bs-toggle="modal" data-bs-dismiss="modal" Text="OK" OnClientClick="return CheckComments();" OnClick="btnOk_Click" />
                                <asp:Button runat="server" ID="btnCancel" CssClass="btn btn-default" data-bs-target="#exampleModalToggle" data-bs-toggle="modal" data-bs-dismiss="modal" Text="Cancel" OnClick="btnCloseSecondPopUp_Click" />
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.modal-dialog -->
            </div>
            <!-- /.modal -->
            <script type="text/javascript">
                $(window).on('load', function () {
                    $('#preloader').fadeOut('slow');
                });
                function CheckComments() {
                    $('.error').remove();
                    var flag = true;
                    var comments = $('#<%=txtComments.ClientID%>').val();
                    if (comments.trim().length == 0) {
                        $('#<%=txtComments.ClientID%>').addClass('border border-danger').after('<span class="text-danger error">Please enter valid Comment</span>');
                        flag = false;
                    } else {
                        $('#<%=txtComments.ClientID%>').removeClass('border-danger').addClass('border-success');
                    }
                    return flag;
                }
                $(document).ready(function () {
                    if (typeof (Sys) != "undefined") {
                        var prm = Sys.WebForms.PageRequestManager.getInstance();
                        prm.add_endRequest(function () {
                            CheckComments();
                        })
                    }
                });
            var exportTimer = null;
            var attemptCounter = 0;
            function startExport() {
                // Show the overlay and loader               
                var loader = document.getElementById('exportLoader');
                if (loader) {
                    loader.style.setProperty('display', 'flex', 'important');
                }
                attemptCounter = 0;
                if (exportTimer) {
                    clearInterval(exportTimer);
                    exportTimer = null;
                }
                exportTimer = setInterval(function () {
                    attemptCounter++;
                    if (attemptCounter >= 30) {
                        clearInterval(exportTimer);
                        exportTimer = null;
                        var targetLoader = document.getElementById('exportLoader');
                        if (targetLoader) {                         
                            targetLoader.style.setProperty('display', 'none', 'important');
                        }
                        return;
                    }
                    var cookies = document.cookie.split(';');
                    for (var i = 0; i < cookies.length; i++) {                      
                        var cookie = cookies[i].trim();                      
                        if (cookie.indexOf("ExportDownloadToken=") !== -1 || cookie.indexOf("ExportDownloadComplete=") !== -1) {
                            clearInterval(exportTimer);
                            // Hide the overlay when download finishes
                            var targetLoader = document.getElementById('exportLoader');
                            if (targetLoader) {                             
                                targetLoader.style.setProperty('display', 'none', 'important');
                            }
                            // Remove the completion cookie
                            document.cookie = "ExportDownloadToken=; Max-Age=0; path=/; SameSite=Lax";
                            document.cookie = "ExportDownloadComplete=; Max-Age=0; path=/; SameSite=Lax";
                            break;
                        }
                    }
                }, 500);
                setTimeout(function () {
                    var targetLoader = document.getElementById('exportLoader');
                    if (targetLoader) {                     
                        targetLoader.style.setProperty('display', 'none', 'important');
                    }
                }
                    , 4000);
                return true;
            }
            </script>
            </div>
        </ContentTemplate>
 <Triggers>
 <asp:PostBackTrigger ControlID="btnExport" />
 </Triggers>
    </asp:UpdatePanel>
    <!-- /.content-wrapper -->
       <div id="exportLoader" style="display:none;position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.3);z-index:9999;justify-content:center;align-items:center;">
            <div  style="background:rgba(255,255,255,0.8);padding:10px;border-radius:5px;transform:translate(-50%,-50%); z-index:999;text-align:center;">"         
            <img src="malkom-static-assets/common/images/Loader.gif"
                 alt="Loading..." />
            <br />
            <span>Please wait...</span>
        </div>
        </div>
     <asp:UpdateProgress ID="UpdateProgress1" runat="server" AssociatedUpdatePanelID="updPanel">
     <ProgressTemplate>
         <div id="overlayBlocker"
             style="position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background-color: rgba(0,0,0,0.3); z-index: 998;">
         </div>
         <div style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 999; background: rgba(255, 255, 255, 0.8); padding: 10px; border-radius: 5px; text-align: center;">
             <img src="malkom-static-assets/common/images/Loader.gif" alt="Loading..." />
             <br />
             <span>Please wait...</span>
         </div>
     </ProgressTemplate>
 </asp:UpdateProgress>
</asp:Content>
