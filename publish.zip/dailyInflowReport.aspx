﻿<%@ Page Title="" Language="C#" MasterPageFile="~/masterPage.Master" AutoEventWireup="true" CodeBehind="dailyInflowReport.aspx.cs" Inherits="FCTG_Web.dailyPnrInflowReport" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="mainBodyContent" runat="server">
     <asp:ScriptManager ID="ScriptManager1" runat="server"></asp:ScriptManager>
    <asp:UpdatePanel runat="server" ID="updtpanel1">
        <ContentTemplate>
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <div class="content-header d-none">
                    <div class="container-fluid">
                        <div class="row mb-2">
                            <div class="col-sm-6">
                                <h1 class="m-0 pageTitle">Daily Query Inflow Report </h1>
                            </div>
                            <!-- /.col -->
                            <%--<div class="col-sm-6">
                                <ol class="breadcrumb float-sm-right">
                                    <li class="breadcrumb-item active">Report</li>
                                    <li class="breadcrumb-item active">Daily Query Inflow Report</li>
                                </ol>
                            </div>--%>
                            <!-- /.col -->
                        </div>
                        <!-- /.row -->
                    </div>
                    <!-- /.container-fluid -->
                </div>
                <!-- /.content-header -->

                <!-- Main content -->
                <section class="content">
                    <div class="container-fluid">
                        <!-- Small boxes (Stat box) -->
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h3 class="card-title font-weight-bold">
                                            <i class="fas fa-chart-pie mr-1"></i>
                                            Daily Query Inflow Report</h3>
                                    </div>

                                    <!-- /.card-header -->
                                    <div class="card-body">
                                        <div class="form-row">
                                            <div class="input-group datepicker form-group col-sm-6 col-md-2 col-lg-2" id="reservationdate" data-target-input="nearest">
                                                <asp:TextBox type="text" ID="txtFromDate" name="txtFromDate" runat="server" CssClass="form-control datetimepicker-input" placeholder="From Date" data-date-format="yyyy/MM/dd" data-target="#reservationdate"></asp:TextBox>
                                                <div class="input-group-append" id="lblFromDate" runat="server" data-target="#reservationdate" data-toggle="datetimepicker">
                                                    <span class="input-group-text"><i class="fa fa-calendar-alt text-danger" id="icontxtFromDate"></i></span>
                                                </div>
                                            </div>
                                            <div class="input-group datepicker form-group col-sm-6 col-md-2 col-lg-2" id="reservationdate2" data-target-input="nearest">
                                                <asp:TextBox type="text" ID="txtToDate" name="txtToDate" runat="server" CssClass="form-control datetimepicker-input" placeholder="To Date" data-date-format="yyyy/MM/dd" data-target="#reservationdate2"></asp:TextBox>
                                                <div class="input-group-append" id="lblToDate" runat="server" data-target="#reservationdate2" data-toggle="datetimepicker">
                                                    <span class="input-group-text"><i class="fa fa-calendar-alt text-danger" id="icontxtToDate"></i></span>
                                                </div>
                                            </div>

                                            <div class="form-group col-sm-6 col-md-3 col-lg-3">
                                                <asp:Button ID="Button1" runat="server" CssClass="btn btn-primary" Text="Refresh List" OnClick="Button1_Click" OnClientClick="return fromDateToDateValidation();" type="button" />
                                                <asp:Button ID="Button2" runat="server" CssClass="btn btn-primary" Text="Export" OnClick="Button2_Click" OnCLientClick="return startExport();" />
                                            </div>
                                        </div>
                                        
                                        <div class="tab-content p-0 table-responsive">
                                            <asp:Repeater runat="server" ID="rptRealTimeList">
                                                <HeaderTemplate>
                                                    <div class="table-responsive">
                                                    <table class="table border table-striped table-bordered table-hover mb-0 gridViewTable" id="applicationAuditTable" style="width: 100% ;">
                                                        <thead>
                                                            <tr>
                                                                <th>Month</th>
                                                                <th>Year</th>
                                                                <%--<th>Query ID</th>
                                                                <th>Account Code</th>   --%>                                                             
                                                                <th>Worklist</th>
                                                                <th>1</th>
                                                                <th>2</th>
                                                                <th>3</th>
                                                                <th>4</th>
                                                                <th>5</th>
                                                                <th>6</th>
                                                                <th>7</th>
                                                                <th>8</th>
                                                                <th>9</th>
                                                                <th>10</th>
                                                                <th>11</th>
                                                                <th>12</th>
                                                                <th>13</th>
                                                                <th>14</th>
                                                                <th>15</th>
                                                                 <th>16</th>
                                                                 <th>17</th>
                                                                 <th>18</th>
                                                                 <th>19</th>
                                                                 <th>20</th>
                                                                 <th>21</th>
                                                                 <th>22</th>
                                                                 <th>23</th>
                                                                 <th>24</th>
                                                                 <th>25</th>
                                                                <th>26</th>
                                                                 <th>27</th>
                                                                <th>28</th>
                                                                <th>29</th>
                                                                <th>30</th>
                                                                <th>31</th>
                                                                <th>Total</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                </HeaderTemplate>
                                                <ItemTemplate>
                                                    <tr>
                                                        <asp:PlaceHolder runat="server">
                                                            <td><%# DataBinder.Eval(Container, "DataItem.MONTH")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.YEAR")%></td>
<%--                                                        <td><%# DataBinder.Eval(Container, "DataItem.QueryID")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.Account_Code ")%></td>--%>                                                            
                                                            <td><%# DataBinder.Eval(Container, "DataItem.WORKLIST")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.Day_1")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.Day_2")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.Day_3")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.Day_4")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.Day_5")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.Day_6")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.Day_7")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.Day_8")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.Day_9")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.Day_10")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.Day_11")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.Day_12")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.Day_13")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.Day_14")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.Day_15")%></td>
                                                             <td><%# DataBinder.Eval(Container, "DataItem.Day_16")%></td>
                                                             <td><%# DataBinder.Eval(Container, "DataItem.Day_17")%></td>
                                                             <td><%# DataBinder.Eval(Container, "DataItem.Day_18")%></td>
                                                             <td><%# DataBinder.Eval(Container, "DataItem.Day_19")%></td>
                                                             <td><%# DataBinder.Eval(Container, "DataItem.Day_20")%></td>
                                                             <td><%# DataBinder.Eval(Container, "DataItem.Day_21")%></td>
                                                             <td><%# DataBinder.Eval(Container, "DataItem.Day_22")%></td>
                                                             <td><%# DataBinder.Eval(Container, "DataItem.Day_23")%></td>
                                                             <td><%# DataBinder.Eval(Container, "DataItem.Day_24")%></td>
                                                             <td><%# DataBinder.Eval(Container, "DataItem.Day_25")%></td>
                                                             <td><%# DataBinder.Eval(Container, "DataItem.Day_26")%></td>
                                                             <td><%# DataBinder.Eval(Container, "DataItem.Day_27")%></td>
                                                             <td><%# DataBinder.Eval(Container, "DataItem.Day_28")%></td>
                                                             <td><%# DataBinder.Eval(Container, "DataItem.Day_29")%></td>
                                                             <td><%# DataBinder.Eval(Container, "DataItem.Day_30")%></td>
                                                            <td><%# DataBinder.Eval(Container, "DataItem.Day_31")%></td>
                                                             <td><%# DataBinder.Eval(Container, "DataItem.total")%></td>
                                                        </asp:PlaceHolder>
                                                    </tr>
                                                </ItemTemplate>
                                                <FooterTemplate>
                                                    </tbody>
                                   </table>
                                                    </div>
                                                </FooterTemplate>
                                            </asp:Repeater>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.card-body -->
                            </div>
                        </div>
                        <!-- /.col-->
                    </div>

                    <!-- /.row -->
                    <!-- /.container-fluid -->
                </section>
                <!-- /.content -->
                <%--<div style="padding-top:30px">
       
            <asp:Table runat="server">
                <asp:TableRow>
                    
                    <asp:TableCell>
                        <label runat="server" >Start Date</label>
                          <asp:TextBox runat="server" ID="txtStartDate"></asp:TextBox>
                        
                         <ajaxToolkit:CalendarExtender ID="CalendarExtender2" TargetControlID="txtStartDate"  runat="server" />
                          <asp:ImageButton runat="server"  ID="ImageButton1" ImageUrl="~/Images/Imagebutton.ico" Width="40px" Height="40px" ImageAlign="Bottom"/>
                    </asp:TableCell>

                     <asp:TableCell>
                          <label runat="server" >End Date</label>
                          <asp:TextBox runat="server" ID="txtEndDate"></asp:TextBox>
                        
                         <ajaxToolkit:CalendarExtender ID="CalendarExtender1" TargetControlID="txtEndDate"  runat="server" />
                          <asp:ImageButton runat="server"  ID="imgPopup" ImageUrl="~/Images/Imagebutton.ico" Width="40px" Height="40px" ImageAlign="Bottom"/>
                       
                    </asp:TableCell>

                    <asp:TableCell>
                          <asp:Button ID="btnSearch" Text="Search" OnClick="btnSearch_Click" runat="server" />
                    </asp:TableCell>
                </asp:TableRow>
            </asp:Table>


        </div>--%>
            </div>
            <script type="text/javascript">
                $(window).on('load', function () {
                    $('#preloader').fadeOut('slow');
                });
                $(document).ready(function () {
                    if (typeof (Sys) != "undefined") {
                        var prm = Sys.WebForms.PageRequestManager.getInstance();
                        prm.add_endRequest(function () {
                            $('#reservationdate, #reservationdate2').datetimepicker({
                                format: 'L'
                            });
                        })
                    };
                    //Date picker
                    $('#reservationdate, #reservationdate2').datetimepicker({
                        format: 'L'
                    });

                });

            var exportTimer = null;
            var attemptCounter = 0;
            function startExport() {
                // Show the overlay and loader               
                var loader = document.getElementById('exportLoader');

                if (loader) {
                    loader.style.setProperty('display', 'flex', 'important');
                }
                attemptCounter = 0;
                if (exportTimer) {
                    clearInterval(exportTimer);
                    exportTimer = null;
                }

                exportTimer = setInterval(function () {
                    attemptCounter++;

                    if (attemptCounter >= 30) {
                        clearInterval(exportTimer);
                        exportTimer = null;

                        var targetLoader = document.getElementById('exportLoader');
                        if (targetLoader) {                         
                            targetLoader.style.setProperty('display', 'none', 'important');
                        }
                        return;
                    }

                    var cookies = document.cookie.split(';');

                    for (var i = 0; i < cookies.length; i++) {                       
                        var cookie = cookies[i].trim();                       
                        if (cookie.indexOf("ExportDownloadToken=") !== -1 || cookie.indexOf("ExportDownloadComplete=") !== -1) {
                          
                            clearInterval(exportTimer);

                            // Hide the overlay when download finishes

                            var targetLoader = document.getElementById('exportLoader');
                            if (targetLoader) {                                
                                targetLoader.style.setProperty('display', 'none', 'important');
                            }

                            // Remove the completion cookie
                            document.cookie = "ExportDownloadToken=; Max-Age=0; path=/; SameSite=Lax";
                            document.cookie = "ExportDownloadComplete=; Max-Age=0; path=/; SameSite=Lax";
                            break;
                        }
                    }

                }, 500);

                setTimeout(function () {

                    var targetLoader = document.getElementById('exportLoader');
                    if (targetLoader) {                        
                        targetLoader.style.setProperty('display', 'none', 'important');
                    }
                }
                    , 4000);

                return true;

            }
            </script>
        </ContentTemplate>
   


 <Triggers>
<asp:PostBackTrigger ControlID="Button2" />
</Triggers>
   </asp:UpdatePanel>

    <div id="exportLoader" style="display:none;position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.3);z-index:9999;justify-content:center;align-items:center;">

        <div  style="background:rgba(255,255,255,0.8);padding:10px;border-radius:5px;transform:translate(-50%,-50%); z-index:999;text-align:center;">"         
            
        <img src="malkom-static-assets/common/images/Loader.gif"
                alt="Loading..." />
        <br />
        <span>Please wait...</span>
    </div>
    </div>

   
    <asp:UpdateProgress ID="UpdateProgress1" runat="server" AssociatedUpdatePanelID="updtpanel1">
    <ProgressTemplate>
        <div id="overlayBlocker"
            style="position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background-color: rgba(0,0,0,0.3); z-index: 998;">
        </div>
        <div style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 999; background: rgba(255, 255, 255, 0.8); padding: 10px; border-radius: 5px; text-align: center;">
            <img src="malkom-static-assets/common/images/Loader.gif" alt="Loading..." />
            <br />
            <span>Please wait...</span>
        </div>
    </ProgressTemplate>
</asp:UpdateProgress>



</asp:Content>
