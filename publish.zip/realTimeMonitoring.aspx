﻿<%@ Page Title="Real Time Montoring" Language="C#" MasterPageFile="~/masterPage.Master" AutoEventWireup="true" CodeBehind="realTimeMonitoring.aspx.cs" Inherits="FCTG_WEB.realTimeMonitoring" %>


<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="mainBodyContent" runat="server">
    <!-- Content Wrapper. Contains page content -->
    <asp:ScriptManager runat="server"></asp:ScriptManager>
    <asp:UpdatePanel ID="updPanel" runat="server">
        <ContentTemplate>
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <div class="content-header d-none">
                    <div class="container-fluid">
                        <div class="row mb-2">
                            <div class="col-sm-6">
                                <h1 class="m-0 pageTitle">Realtime Monitoring</h1>
                            </div>
                            <!-- /.col -->
                          <%--  <div class="col-sm-6">
                                <ol class="breadcrumb float-sm-right">
                                    <li class="breadcrumb-item active">Report</li>
                                    <li class="breadcrumb-item active">Realtime Monitoring</li>
                                </ol>
                            </div>--%>
                            <!-- /.col -->
                        </div>
                        <!-- /.row -->
                    </div>
                    <!-- /.container-fluid -->
                </div>

                <!-- /.content-header -->
                <!-- Main content -->
                <section class="content">
                    <div class="container-fluid">
                        <!-- Small boxes (Stat box) -->
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h3 class="card-title font-weight-bold">
                                            <i class="fas fa-chart-pie mr-1"></i>
                                            RealTime Monitoring List</h3>
                                        <div class="card-tools">
                                            <asp:Button ID="btnRefresh" runat="server" CssClass="btn btn-sm btn-primary" Text="Refresh List" OnClick="btnRefreshList_Click" />
                                            <asp:Button ID="btnExport" runat="server" CssClass="btn btn-sm btn-primary" Text="Export" OnClick="btnExport_Click"  OnCLientClick="return startExport();" />
                                        </div>
                                    </div>
                                    <!-- /.card-header -->
                                    <!--Repeator Control-->
                                    <div class="card-body">
                                        <div class="tab-content p-0">

                                            <asp:Repeater runat="server" ID="rptRealTimeList">
                                                <HeaderTemplate>
                                                    <div class="table-responsive">
                                                        <table class="table border table-striped table-bordered table-hover mb-0 gridViewTable text-nowrap" id="applicationAuditTable" style="width: 100%">
                                                            <thead>

                                                                <tr>
                                                                    <th>#</th>
                                                                    <th>Agent ID</th>
                                                                    <th>Agent Name</th>
                                                                    <th>Team Leader Name</th>
                                                                    <th>Current Status</th>
                                                                    <th>Case Number</th>
                                                                    <th>Worklist</th>
                                                                    <%--<th>Case Number</th>
                                                                    <th>Job Type</th>--%>
                                                                    <th>Priority</th>
                                                                    <th>Elapsed Time</th>
                                                                    <%--<th class="border-right">Identification Text</th>--%>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                </HeaderTemplate>

                                                <ItemTemplate>
                                                    <tr>
                                                        <td><%# Container.ItemIndex + 1 %></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.AGENT_ID")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.AGENT_NAME")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.TEAM_LEADER_NAME")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.CURRENT_STATUS")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.RECORD_LOCATOR")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.FUNCTION_NAME")%></td>
                                                         <%--<td class="more"></td>
                                                         <td class="more"><%# DataBinder.Eval(Container, "DataItem.JOB_TYPE")%></td>--%>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.PRIORITY_NO")%></td>
                                                        <td class="more"><%# DataBinder.Eval(Container, "DataItem.ELAPSED_TIME")%></td>

                                                    </tr>
                                                </ItemTemplate>
                                                <FooterTemplate>
                                                    </tbody>
                                   </table>
                                                    </div>
                                                </FooterTemplate>
                                            </asp:Repeater>
                                        </div>
                                        <asp:Label ID="lblRecord" runat="server" Text=""></asp:Label>
                                    </div>
                                    <!-- /.card-body -->
                                </div>
                            </div>
                            <!-- /.col-->
                        </div>
                        <!-- /.row -->
                    </div>
                    <!-- /.container-fluid -->
                </section>
                <!-- /.content -->
            </div>
            <script type="text/javascript">
                $(window).on('load', function () {
                    $('#preloader').fadeOut('slow');
                });


            var exportTimer = null;
            var attemptCounter = 0;
            function startExport() {
                // Show the overlay and loader
                
                var loader = document.getElementById('exportLoader');

                if (loader) {
                    loader.style.setProperty('display', 'flex', 'important');
                }
                attemptCounter = 0;
                if (exportTimer) {
                    clearInterval(exportTimer);
                    exportTimer = null;
                }

                exportTimer = setInterval(function () {
                    attemptCounter++;

                    if (attemptCounter >= 30) {
                        clearInterval(exportTimer);
                        exportTimer = null;

                        var targetLoader = document.getElementById('exportLoader');
                        if (targetLoader) {                          
                            targetLoader.style.setProperty('display', 'none', 'important');
                        }
                        return;
                    }

                    var cookies = document.cookie.split(';');

                    for (var i = 0; i < cookies.length; i++) {                       
                        var cookie = cookies[i].trim();                       
                        if (cookie.indexOf("ExportDownloadToken=") !== -1 || cookie.indexOf("ExportDownloadComplete=") !== -1) {
                           
                            clearInterval(exportTimer);

                            // Hide the overlay when download finishes

                            var targetLoader = document.getElementById('exportLoader');
                            if (targetLoader) {                              
                                targetLoader.style.setProperty('display', 'none', 'important');
                            }

                            // Remove the completion cookie
                            document.cookie = "ExportDownloadToken=; Max-Age=0; path=/; SameSite=Lax";
                            document.cookie = "ExportDownloadComplete=; Max-Age=0; path=/; SameSite=Lax";
                            break;
                        }
                    }

                }, 500);

                setTimeout(function () {

                    var targetLoader = document.getElementById('exportLoader');
                    if (targetLoader) {                        
                        targetLoader.style.setProperty('display', 'none', 'important');
                    }
                }
                    , 4000);

                return true;
            }


            </script>
        </ContentTemplate>
 

     <Triggers>
 <asp:PostBackTrigger ControlID="btnExport" />
 </Triggers>
    </asp:UpdatePanel>

    <div id="exportLoader" style="display:none;position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.3);z-index:9999;justify-content:center;align-items:center;">

        <div  style="background:rgba(255,255,255,0.8);padding:10px;border-radius:5px;transform:translate(-50%,-50%); z-index:999;text-align:center;">"         
            
        <img src="malkom-static-assets/common/images/Loader.gif"
                alt="Loading..." />
        <br />
        <span>Please wait...</span>
    </div>
    </div>

    
     <asp:UpdateProgress ID="UpdateProgress1" runat="server" AssociatedUpdatePanelID="updPanel">
     <ProgressTemplate>
         <div id="overlayBlocker"
             style="position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background-color: rgba(0,0,0,0.3); z-index: 998;">
         </div>
         <div style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 999; background: rgba(255, 255, 255, 0.8); padding: 10px; border-radius: 5px; text-align: center;">
             <img src="malkom-static-assets/common/images/Loader.gif" alt="Loading..." />
             <br />
             <span>Please wait...</span>
         </div>
     </ProgressTemplate>
 </asp:UpdateProgress>
</asp:Content>
